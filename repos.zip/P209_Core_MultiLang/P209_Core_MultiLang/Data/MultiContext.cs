﻿using Microsoft.EntityFrameworkCore;
using P209_Core_MultiLang.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P209_Core_MultiLang.Data
{
    public class MultiContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseLazyLoadingProxies();
        }

        public MultiContext(DbContextOptions<MultiContext> options) : base(options)
        {
        }

        public DbSet<Language> Languages { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<ProductTL> ProductTLs { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<CategoryTL> CategoryTLs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Language>().HasData(
                new Language { Id = 1, Name = "az" },
                new Language { Id = 2, Name = "en" },
                new Language { Id = 3, Name = "ru" }
            );

            modelBuilder.Entity<Category>().HasData(
                new Category { Id = 1 },
                new Category { Id = 2 }
            );

            modelBuilder.Entity<CategoryTL>().HasData(
                new CategoryTL { Id = 1, CategoryId = 1, LanguageId = 1, Name = "Məişət əşyaları" },
                new CategoryTL { Id = 2, CategoryId = 1, LanguageId = 2, Name = "Housing" },
                new CategoryTL { Id = 3, CategoryId = 1, LanguageId = 3, Name = "Бытовая техника" },
                new CategoryTL { Id = 4, CategoryId = 2, LanguageId = 1, Name = "Geyim" },
                new CategoryTL { Id = 5, CategoryId = 2, LanguageId = 2, Name = "Clothing" },
                new CategoryTL { Id = 6, CategoryId = 2, LanguageId = 3, Name = "Одежда" }
            );

            modelBuilder.Entity<Product>().HasData(
                new Product { Id = 1, CategoryId = 1, Image = "products/default.png" },
                new Product { Id = 2, CategoryId = 2, Image = "products/default.png" },
                new Product { Id = 3, CategoryId = 2, Image = "products/default.png" }
            );

            modelBuilder.Entity<ProductTL>().HasData(
                new ProductTL { Id = 1,  ProductId = 1, LanguageId = 1, Name = "Ütü", Description = "Evinizin vazgeçilməzi olan ütülər!!!", },
                new ProductTL { Id = 2, ProductId = 1, LanguageId = 2, Name = "Iron", Description = "Irons that are indispensable for your home!!!", },
                new ProductTL { Id = 3, ProductId = 1, LanguageId = 3, Name = "Утюг", Description = "Утюги, которые необходимы для вашего дома!!!", },
                new ProductTL { Id = 4, ProductId = 2, LanguageId = 1, Name = "Ayaqqabı", Description = "Mövsümün ideal ayaqqabıları. Ancaq Yasingildə!!!", },
                new ProductTL { Id = 5, ProductId = 2, LanguageId = 2, Name = "Shoes", Description = "Ideal season shoes. But in Yoslinli!!!", },
                new ProductTL { Id = 6, ProductId = 2, LanguageId = 3, Name = "Oбувь", Description = "Идеальная сезонная обувь. Но в Ясине!!!", },
                new ProductTL { Id = 7, ProductId = 3, LanguageId = 1, Name = "Şarf", Description = "Mövsümün ideal şarfları. Ancaq bizdə!!!", },
                new ProductTL { Id = 8, ProductId = 3, LanguageId = 2, Name = "Scarf", Description = "The ideal season of the season. But we have!!!", },
                new ProductTL { Id = 9, ProductId = 3, LanguageId = 3, Name = "Шарф", Description = "Идеальное время года. Но у нас есть!!!", }
            );
        }
    }
}
