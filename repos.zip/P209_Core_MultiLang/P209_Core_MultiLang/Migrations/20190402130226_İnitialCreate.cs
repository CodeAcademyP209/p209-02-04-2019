﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace P209_Core_MultiLang.Migrations
{
    public partial class İnitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Languages",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Languages", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Image = table.Column<string>(nullable: true),
                    CategoryId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Products_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "CategoryTLs",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(maxLength: 100, nullable: true),
                    CategoryId = table.Column<int>(nullable: false),
                    LanguageId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CategoryTLs", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CategoryTLs_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CategoryTLs_Languages_LanguageId",
                        column: x => x.LanguageId,
                        principalTable: "Languages",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProductTLs",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(maxLength: 100, nullable: false),
                    Description = table.Column<string>(maxLength: 500, nullable: true),
                    ProductId = table.Column<int>(nullable: false),
                    LanguageId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductTLs", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProductTLs_Languages_LanguageId",
                        column: x => x.LanguageId,
                        principalTable: "Languages",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProductTLs_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                column: "Id",
                values: new object[]
                {
                    1,
                    2
                });

            migrationBuilder.InsertData(
                table: "Languages",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "az" },
                    { 2, "en" },
                    { 3, "ru" }
                });

            migrationBuilder.InsertData(
                table: "CategoryTLs",
                columns: new[] { "Id", "CategoryId", "LanguageId", "Name" },
                values: new object[,]
                {
                    { 1, 1, 1, "Məişət əşyaları" },
                    { 4, 2, 1, "Geyim" },
                    { 2, 1, 2, "Housing" },
                    { 5, 2, 2, "Clothing" },
                    { 3, 1, 3, "Бытовая техника" },
                    { 6, 2, 3, "Одежда" }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "Id", "CategoryId", "Image" },
                values: new object[,]
                {
                    { 1, 1, "products/default.png" },
                    { 2, 2, "products/default.png" },
                    { 3, 2, "products/default.png" }
                });

            migrationBuilder.InsertData(
                table: "ProductTLs",
                columns: new[] { "Id", "Description", "LanguageId", "Name", "ProductId" },
                values: new object[,]
                {
                    { 1, "Evinizin vazgeçilməzi olan ütülər!!!", 1, "Ütü", 1 },
                    { 2, "Irons that are indispensable for your home!!!", 2, "Iron", 1 },
                    { 3, "Утюги, которые необходимы для вашего дома!!!", 3, "Утюг", 1 },
                    { 4, "Mövsümün ideal ayaqqabıları. Ancaq Yasingildə!!!", 1, "Ayaqqabı", 2 },
                    { 5, "Ideal season shoes. But in Yoslinli!!!", 2, "Shoes", 2 },
                    { 6, "Идеальная сезонная обувь. Но в Ясине!!!", 3, "Oбувь", 2 },
                    { 7, "Mövsümün ideal şarfları. Ancaq bizdə!!!", 1, "Şarf", 3 },
                    { 8, "The ideal season of the season. But we have!!!", 2, "Scarf", 3 },
                    { 9, "Идеальное время года. Но у нас есть!!!", 3, "Шарф", 3 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_CategoryTLs_CategoryId",
                table: "CategoryTLs",
                column: "CategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_CategoryTLs_LanguageId",
                table: "CategoryTLs",
                column: "LanguageId");

            migrationBuilder.CreateIndex(
                name: "IX_Products_CategoryId",
                table: "Products",
                column: "CategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductTLs_LanguageId",
                table: "ProductTLs",
                column: "LanguageId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductTLs_ProductId",
                table: "ProductTLs",
                column: "ProductId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CategoryTLs");

            migrationBuilder.DropTable(
                name: "ProductTLs");

            migrationBuilder.DropTable(
                name: "Languages");

            migrationBuilder.DropTable(
                name: "Products");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
