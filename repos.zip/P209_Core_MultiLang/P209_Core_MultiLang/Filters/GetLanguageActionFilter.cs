﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace P209_Core_MultiLang.Filters
{
    public class GetLanguageActionFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            //get current culture as 2-letter name
            string lang = context.HttpContext.Features.Get<IRequestCultureFeature>()
                          .RequestCulture.Culture.TwoLetterISOLanguageName;

            //get an instance of IOptions from IoC container
            var locOptions = context.HttpContext.RequestServices.GetService<IOptions<RequestLocalizationOptions>>();

            //making Culture default "az"
            if (!locOptions.Value.SupportedCultures.Any(c => c.TwoLetterISOLanguageName == lang))
                lang = "az";

            //add new argument to action for lang
            context.ActionArguments["lang"] = lang;
        }
    }
}
