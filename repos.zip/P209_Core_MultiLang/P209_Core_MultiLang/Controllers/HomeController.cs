﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using P209_Core_MultiLang.Data;
using P209_Core_MultiLang.Models;

namespace P209_Core_MultiLang.Controllers
{
    public class HomeController : Controller
    {
        private readonly MultiContext _context;

        public HomeController(MultiContext context)
        {
            _context = context;
        }

        public IActionResult Index(string lang)
        {
            return View(_context.ProductTLs.Where(t => t.Language.Name == lang));
        }

        public IActionResult About(string lang)
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        public IActionResult SetLanguage(string culture, string returnUrl)
        {
            Response.Cookies.Append(
                CookieRequestCultureProvider.DefaultCookieName,
                CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture)),
                new CookieOptions { Expires = DateTimeOffset.UtcNow.AddYears(1), IsEssential = true }
            );

            Uri uri = new Uri($"{Request.Scheme}://{Request.Host}" + returnUrl.Substring(1));
            return Redirect(uri.AbsoluteUri);
        }
    }
}
