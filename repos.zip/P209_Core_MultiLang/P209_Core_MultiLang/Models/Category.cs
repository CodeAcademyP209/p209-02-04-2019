﻿using System.Collections.Generic;

namespace P209_Core_MultiLang.Models
{
    public class Category
    {
        public Category()
        {
            CategoryTLs = new HashSet<CategoryTL>();
            Products = new HashSet<Product>();
        }

        public int Id { get; set; }

        public virtual ICollection<CategoryTL> CategoryTLs { get; set; }
        public virtual ICollection<Product> Products { get; set; }
    }
}
