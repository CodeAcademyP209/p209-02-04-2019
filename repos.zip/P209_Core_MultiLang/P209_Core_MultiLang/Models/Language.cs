﻿namespace P209_Core_MultiLang.Models
{
    public class Language
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
