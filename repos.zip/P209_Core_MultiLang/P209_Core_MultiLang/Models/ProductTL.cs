﻿using System.ComponentModel.DataAnnotations;

namespace P209_Core_MultiLang.Models
{
    public class ProductTL
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        public int ProductId { get; set; }
        public int LanguageId { get; set; }

        public virtual Product Product { get; set; }
        public virtual Language Language { get; set; }
    }
}
