﻿using System.ComponentModel.DataAnnotations;

namespace P209_Core_MultiLang.Models
{
    public class CategoryTL
    {
        public int Id { get; set; }

        [StringLength(100)]
        public string Name { get; set; }

        public int CategoryId { get; set; }
        public int LanguageId { get; set; }

        public virtual Category Category { get; set; }
        public virtual Language Language { get; set; }
    }
}
