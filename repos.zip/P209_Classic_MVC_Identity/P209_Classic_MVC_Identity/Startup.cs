﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(P209_Classic_MVC_Identity.Startup))]
namespace P209_Classic_MVC_Identity
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
